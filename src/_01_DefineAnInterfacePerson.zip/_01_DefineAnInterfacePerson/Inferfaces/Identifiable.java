package _01_DefineAnInterfacePerson.Inferfaces;

public interface Identifiable {
    String getId();

}
