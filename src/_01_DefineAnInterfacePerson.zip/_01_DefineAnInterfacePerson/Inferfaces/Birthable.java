package _01_DefineAnInterfacePerson.Inferfaces;

public interface Birthable {

    String getBirthDate();
}
