package _01_DefineAnInterfacePerson.Inferfaces;

public interface Person {

    String getName();
    int getAge();
}
